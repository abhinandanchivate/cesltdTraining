<template>
  <h2>Teams Footer</h2>
</template>