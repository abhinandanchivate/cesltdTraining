module.exports = {
  HOST: "0.0.0.0",
  PORT: 27017,
  DB: "bezkoder_db"
};