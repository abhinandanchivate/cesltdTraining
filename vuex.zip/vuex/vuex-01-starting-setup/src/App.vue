<template>
  <base-container title="Vuex"></base-container>
  <the-counter></the-counter>
  <button @click="addOne">Add One</button>
</template>

<script>
import BaseContainer from './components/BaseContainer.vue';
import TheCounter from './components/TheCounter.vue';
export default {
  components: {
    BaseContainer,
    TheCounter,
  },

  methods: {
    addOne() {
      this.$store.state.counter++;
    },
  },
};
</script>

<style>
* {
  box-sizing: border-box;
}

html {
  font-family: sans-serif;
}

body {
  margin: 0;
}
</style>
