export default {
  userIsAuthenticated(state) {
    return state.isLoggedIn;
  }
};